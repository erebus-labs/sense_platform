/**
  ******************************************************************************
  * File Name          : main.c
  * Date               : 03/05/2015 21:54:47
  * Description        : Main program body
  ******************************************************************************
  *
  * COPYRIGHT(c) 2015 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stm32f2xx_hal.h"
#include "ff.h"
#include "ff_gen_drv.h"
#include "sd_diskio.h" /* defines SD_Driver as external */
#include "adc.h"
#include "i2c.h"
#include "rtc.h"
#include "sdio.h"
#include "usart.h"
#include "gpio.h"
#include "dma.h"
#include "SENSORS.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

/* USER CODE BEGIN Includes */
#define DEBUG
#define MAX_LEN 10
#define __USE_IRQ

#define ADC_TYPE 0
#define I2C_TYPE 1
#define UNUSED '\0'

#define RED_PIN_BANK GPIOB
#define GREEN_PIN_BANK GPIOC

/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/

uint8_t retSD;    /* Return value for SD */
char SDPath[4];  /* SD logical drive path */
FATFS SDFatFs;  /* File system object for SD card logical drive */
FIL MyFile;     /* File object */
FRESULT res;                                          /* FatFs function common result code */
uint32_t byteswritten, bytesread;                     /* File write/read counts */
uint8_t wtext[] = "ECE CAPSTONE SD Test2:"; /* File write buffer */
uint8_t rtext[100];                               /* File read buffer */

uint8_t PROGRAM_STATE=0;

volatile uint32_t adc1;
volatile uint32_t I2C_value;

typedef struct t_settings{
	uint8_t ACCEL_SET;
	uint8_t ADC1_SET;
	uint8_t ADC2_SET;
	uint8_t ADC3_SET;
	uint8_t ADC4_SET;
}T_SET;
T_SET timers;

typedef struct sensor{
	char * name;
	uint8_t type;
	uint8_t array_index;
	uint32_t alarm;
	uint32_t data;
	//need to add a "conversion factor" entry, may define as a macro...
}SENS;
SENS sensors[10];

static uint32_t ACCEL_COUNTER;
static uint32_t ACCEL_SCHEDULE=10;

static uint32_t ADC1_COUNTER;
static uint32_t ADC1_SCHEDULE=1;

static uint32_t ADC2_COUNTER;
static uint32_t ADC2_SCHEDULE=5;

static uint32_t ADC3_COUNTER;
static uint32_t ADC3_SCHEDULE=3600;

uint8_t data_to_read;

uint64_t SD_write_address=0;

static DMA_HandleTypeDef hdma_sdio;

//SD_HandleTypeDef SD_CARD;

ADC_ChannelConfTypeDef sConfig;

/*Variables for string receive over USART:*/
char rxBuffer = '\000';
char rx_string[MAX_LEN];
char txBuffer[] = "SERIAL PRINT\n";

char USART_ENABLED[]="UART3 RX ENABLED\r";
char USART_DISABLED[]="UART3 RX DISABLED\r";
int rx_index=0;

/*Peripheral functions:*/
void SystemClock_Config(void);
void GPIO_INIT(void);
void ADC_INIT(void);
void I2C_INIT(void);
void IRQ_INIT(void);
void USART_INIT(void);
void SD_CARD_INIT(void);
void ARBITRATE(void);
void SD_write_test(void);
void Error_Handler(void);
void USART3_ENABLE(void);
void USART3_ENABLE(void);
void print(char string[]);

void I2C_DEVICE_INIT(I2C_HandleTypeDef *, uint8_t dev_id);
void LIGHT_LEDS(uint32_t);

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);

int main(void)
{
  SD_HandleTypeDef SD_CARD;
  HAL_SD_CardInfoTypedef SD_CardInfo;
  /* MCU Configuration----------------------------------------------------------*/
  FRESULT res;                                          /* FatFs function common result code */
  uint32_t byteswritten, bytesread;                     /* File write/read counts */
  uint8_t wtext[] = "This is STM32 working with FatFs"; /* File write buffer */
  uint8_t rtext[100];                                   /* File read buffer */
  
  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* Configure the system clock */
  SystemClock_Config();

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_ADC1_Init();
  MX_ADC2_Init();
  MX_ADC3_Init();
  //MX_I2C1_Init();
  MX_RTC_Init();
  MX_SDIO_SD_Init();

  /* USER CODE BEGIN 2 */
  ADC_INIT();
  USART_INIT();
  I2C_INIT();
  GPIO_INIT();
  IRQ_INIT();
  HAL_SD_Init(&SD_CARD, &SD_CardInfo);
  //I2C_DEVICE_INIT(&hi2c1, ACCEL_ADDR);
  //SD_CARD_INIT();
  //SD_write_test();
  /* USER CODE END 2 */

  /*## FatFS: Link the SD driver ###########################*/
  retSD = FATFS_LinkDriver(&SD_Driver, SDPath);

  /* USER CODE BEGIN 3 */
  /* Infinite loop */
  while (1)
  {
	 __WFI();

  }
  /* USER CODE END 3 */
}
/** System Clock Configuration
*/
void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_PeriphCLKInitTypeDef PeriphClkInitStruct;

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_LSI
                              |RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = 6;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  HAL_RCC_OscConfig(&RCC_OscInitStruct);

  PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_RTC;
  PeriphClkInitStruct.RTCClockSelection = RCC_RTCCLKSOURCE_LSI;
  HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct);

}

/* USER CODE BEGIN 4 */
/******************************************************************************
* @brief  print(char string[])
* @param  string to print
* @retval NONE
******************************************************************************/
void print(char string[]){
	if(HAL_UART_GetState(&huart3) != HAL_UART_STATE_BUSY_TX_RX){
		HAL_UART_Transmit_IT(&huart3, (uint8_t*)string, strlen(string));	
	//sprintf(
	}
}
/******************************************************************************
* @brief  ADC_INIT(void)
* @param  NONE
* @retval NONE
******************************************************************************/
void ADC_INIT(void){
	/**Configure the global features of the ADC*/
	__ADC1_CLK_ENABLE();
	__ADC2_CLK_ENABLE();
	__ADC3_CLK_ENABLE();

	hadc1.Instance = ADC1;
	hadc1.Init.ClockPrescaler = ADC_CLOCKPRESCALER_PCLK_DIV2;
	hadc1.Init.Resolution = ADC_RESOLUTION12b;
	hadc1.Init.ScanConvMode = DISABLE;
	hadc1.Init.ContinuousConvMode = DISABLE;
	hadc1.Init.DiscontinuousConvMode = DISABLE;
	hadc1.Init.NbrOfDiscConversion = 0;
	hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;	
	hadc1.Init.ExternalTrigConv = ADC_EXTERNALTRIGCONV_T1_CC1;
	hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
	hadc1.Init.NbrOfConversion = 1;
	hadc1.Init.DMAContinuousRequests = ENABLE;//ENABLE;
	hadc1.Init.EOCSelection = EOC_SINGLE_CONV; //DISABLE;//
	HAL_ADC_Init(&hadc1);

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
	sConfig.Channel = ADC_CHANNEL_1; //changed from 0
	sConfig.Rank = 1;
	sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;//changed from 3 cycles
	sConfig.Offset = 0;
	HAL_ADC_ConfigChannel(&hadc1, &sConfig);
	
	hadc2.Instance = ADC2;
	hadc2.Init.ClockPrescaler = ADC_CLOCKPRESCALER_PCLK_DIV2;
	hadc2.Init.Resolution = ADC_RESOLUTION12b;
	hadc2.Init.ScanConvMode = DISABLE;
	hadc2.Init.ContinuousConvMode = DISABLE;
	hadc2.Init.DiscontinuousConvMode = DISABLE;
	hadc2.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
	hadc2.Init.DataAlign = ADC_DATAALIGN_RIGHT;
	hadc2.Init.NbrOfConversion = 1;
	hadc2.Init.DMAContinuousRequests = DISABLE;
	hadc2.Init.EOCSelection = EOC_SINGLE_CONV;
	HAL_ADC_Init(&hadc2);

	/**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
	sConfig.Channel = ADC_CHANNEL_2;
	sConfig.Rank = 1;
	sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
	HAL_ADC_ConfigChannel(&hadc2, &sConfig);
	
	 /**Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion) 
    */
	hadc3.Instance = ADC3;
	hadc3.Init.ClockPrescaler = ADC_CLOCKPRESCALER_PCLK_DIV2;
	hadc3.Init.Resolution = ADC_RESOLUTION12b;
	hadc3.Init.ScanConvMode = DISABLE;
	hadc3.Init.ContinuousConvMode = DISABLE;
	hadc3.Init.DiscontinuousConvMode = DISABLE;	
	hadc3.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
	hadc3.Init.DataAlign = ADC_DATAALIGN_RIGHT;
	hadc3.Init.NbrOfConversion = 1;
	hadc3.Init.DMAContinuousRequests = DISABLE;
	hadc3.Init.EOCSelection = EOC_SINGLE_CONV;
	HAL_ADC_Init(&hadc3);

	/**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
	sConfig.Channel = ADC_CHANNEL_3;
	sConfig.Rank = 1;
	sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
	HAL_ADC_ConfigChannel(&hadc3, &sConfig);

	//HAL_DMA_Start_IT(&hdma_adc, (uint32_t)&hadc1.Instance->DR, (uint32_t)&uhADCxConvertedValue, sizeof(uint32_t));
}

/******************************************************************************
* @brief  I2C_INIT(void)
* @param  NONE
* @retval NONE
******************************************************************************/
void I2C_INIT(void){

	hi2c1.Instance = I2C1;
	hi2c1.Init.ClockSpeed = 100000;
	hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
	hi2c1.Init.OwnAddress1 = 0x1;
	hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;	
	hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLED;
	hi2c1.Init.OwnAddress2 = 0;
	hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLED;
	hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLED;
	
	while(HAL_OK != HAL_I2C_Init(&hi2c1));

	HAL_I2C_IsDeviceReady(&hi2c1, ACCEL_ADDR, 3, 10);
	
	HAL_I2C_Mem_Write_IT(&hi2c1, ACCEL_WRITE_ADDR, ACCEL_POWER_CTRL, 2, (uint8_t *)ACCEL_WAKE, sizeof(ACCEL_WAKE));
	HAL_I2C_Mem_Write_IT(&hi2c1, ACCEL_WRITE_ADDR, ACCEL_DATA_FMT, 2, (uint8_t *)SELF_TEST_OFF, sizeof(SELF_TEST_OFF));
	HAL_I2C_Mem_Write_IT(&hi2c1, ACCEL_WRITE_ADDR, ACCEL_FIFO_CTRL, 2, (uint8_t *)0x0, sizeof(uint8_t));
	
}
/******************************************************************************
* @brief  IRQ_INIT(void)
* @param  NONE
* @retval NONE
******************************************************************************/
void IRQ_INIT(void){
	/* Peripheral clock enable */
	__HAL_RCC_RTC_ENABLE();
	__I2C1_CLK_ENABLE();


	/* Peripheral interrupt init*/
	HAL_NVIC_SetPriority(RTC_WKUP_IRQn, 0, 0);
	HAL_NVIC_EnableIRQ(RTC_WKUP_IRQn);
	
	HAL_NVIC_SetPriority(RTC_Alarm_IRQn, 0, 0);
	HAL_NVIC_EnableIRQ(RTC_Alarm_IRQn);
	
	/**Enable ADC Interrupts:*/
	HAL_NVIC_SetPriority(ADC_IRQn, 3,0);
	HAL_NVIC_EnableIRQ(ADC_IRQn);
	
	/* ENABLE USART INTERRUPTS:*/
	HAL_NVIC_SetPriority(USART3_IRQn, 2, 0);	
	HAL_NVIC_EnableIRQ(USART3_IRQn);
	
	/*ENABLE I2C INTERRUPTS:*/
	HAL_NVIC_SetPriority(I2C1_EV_IRQn, 0, 0);
	HAL_NVIC_EnableIRQ(I2C1_EV_IRQn);
	HAL_NVIC_SetPriority(I2C1_ER_IRQn, 0, 0);
	HAL_NVIC_EnableIRQ(I2C1_ER_IRQn);
	
	/* EXTI interrupt init*/
	HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
	HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);
}
/******************************************************************************
* @brief  GPIO_INIT(void)
* @param  NONE
* @retval NONE
******************************************************************************/
void GPIO_INIT(void){
  GPIO_InitTypeDef GPIO_InitStruct;

  /* GPIO Ports Clock Enable */
  __GPIOC_CLK_ENABLE();
  __GPIOH_CLK_ENABLE();
  __GPIOA_CLK_ENABLE();
  __GPIOB_CLK_ENABLE();
  __GPIOD_CLK_ENABLE();

  /*Configure GPIO pins : PC13 PC14 PC0 PC1 
                           PC3 PC6 PC7 */
  GPIO_InitStruct.Pin = GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_0|GPIO_PIN_1 
                          |GPIO_PIN_3|GPIO_PIN_6|GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : PC15 */
  GPIO_InitStruct.Pin = GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : PC2 */
  GPIO_InitStruct.Pin = GPIO_PIN_2;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF10_OTG_HS;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PA5 PA6 PA8 PA10 
                           PA15 */
  GPIO_InitStruct.Pin = GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_8|GPIO_PIN_10|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : PA7 */
  GPIO_InitStruct.Pin = GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PC4 PC5 */
  GPIO_InitStruct.Pin = GPIO_PIN_4|GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PB0 PB1 PB15 PB4 
                           PB5 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_15|GPIO_PIN_4|GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : PB2 */
  GPIO_InitStruct.Pin = GPIO_PIN_2;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PB8 PB9 */
  GPIO_InitStruct.Pin = GPIO_PIN_8|GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

	/*Configure PB 10 and 11, USART3 TX, RX*/
	GPIO_InitStruct.Pin = GPIO_PIN_10|GPIO_PIN_11;
	GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_LOW;
	GPIO_InitStruct.Alternate = GPIO_AF7_USART3;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
	
	  /*Configure GPIO pin : PB12 */
	GPIO_InitStruct.Pin = GPIO_PIN_12;
	GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
	/*Initialize ADC:*/
	
	/*Initialize I2C1*/
	/**I2C1 GPIO Configuration    
	PB6     ------> I2C1_SCL
	PB7     ------> I2C1_SDA 
	*/
	GPIO_InitStruct.Pin = GPIO_PIN_6|GPIO_PIN_7;
	GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_HIGH;
	GPIO_InitStruct.Alternate = GPIO_AF4_I2C1;
	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}
/******************************************************************************
* @brief  USART_INIT(void)
* @param  NONE
* @retval NONE
******************************************************************************/
void USART_INIT(void){

	__USART3_CLK_ENABLE();
	__HAL_UART_ENABLE(&huart3);
	
	huart3.Instance = USART3;
	huart3.Init.BaudRate = 9600;
	huart3.Init.WordLength = UART_WORDLENGTH_8B;
	huart3.Init.StopBits = UART_STOPBITS_1;
	huart3.Init.Parity = UART_PARITY_NONE;
	huart3.Init.Mode = UART_MODE_TX_RX;
	huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart3.Init.OverSampling = UART_OVERSAMPLING_16;
	HAL_UART_Init(&huart3);

}/*END INIT USART*/

/******************************************************************************
* @brief  Alarm A callback.
* @param  hrtc: RTC handle
* @retval None
******************************************************************************/
void HAL_RTC_AlarmAEventCallback(RTC_HandleTypeDef *hrtc){
	ARBITRATE();
}
/******************************************************************************
* @brief  Arbitration function for the Alarm A:
*	  -Determines which sensor to sample based on the timer counter
* @param  hrtc: RTC handle
* @retval None
******************************************************************************/
void ARBITRATE(void){
	
	if(ADC1_COUNTER == ADC1_SCHEDULE){
		HAL_ADC_Start_IT(&hadc1);//WORKS!
		ADC1_COUNTER=0;
	}
	else ++ADC1_COUNTER;
	if(ADC2_COUNTER == ADC2_SCHEDULE){
		HAL_ADC_Start_IT(&hadc2);//WORKS!
		ADC2_COUNTER=0;
	}
	else ++ADC2_COUNTER;
	if(ADC3_COUNTER == ADC3_SCHEDULE){
		//HAL_ADC_Start_IT(&hadc3);//WORKS!
		ADC3_COUNTER=0;
	}
	else ++ADC3_COUNTER;
	
	if(ACCEL_COUNTER == ACCEL_SCHEDULE){
		data_to_read=0;
		ACCEL_COUNTER=0;
		//HAL_I2C_IsDeviceReady(&hi2c1, ACCEL_ADDR, 3, 10);
		HAL_I2C_Mem_Read_IT(&hi2c1, ACCEL_ADDR , ACCEL_DATA_X1, sizeof(uint8_t), (uint8_t *)&data_to_read, sizeof(uint8_t));//I2C_MEMADD_SIZE_8BIT);
		//HAL_I2C_Master_Receive_IT(&hi2c1, ACCEL_ADDR, (uint8_t *)&data_to_read, sizeof(data_to_read));
	}
	else ++ACCEL_COUNTER;
}
/******************************************************************************
* @abstract HAL_ADC_ConvCpltCallback function reads from specific ADC device
* @ref HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef * hadc1)
* @param ADC_HandleTypeDef * hadc1
* @retval NONE
******************************************************************************/
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef * hadc){
	char* tx_string;
	__IO uint32_t adc_val=0;
	
	if(hadc->Instance == ADC1){
		adc_val = HAL_ADC_GetValue(&hadc1);
		tx_string = "ADC1 EOC\r";
	}
	if(hadc->Instance == ADC2){
		adc_val = HAL_ADC_GetValue(&hadc2);
		tx_string = "ADC2 EOC\r";		
	}
	if(hadc->Instance == ADC3){
		adc_val = HAL_ADC_GetValue(&hadc3);
		tx_string = "ADC3 EOC\r";		
	}
	#ifdef DEBUG
		LIGHT_LEDS(adc_val);//WORKS with IT
	#endif
	print(tx_string);
	//HAL_SD_WriteBlocks_DMA(&hsd, (uint32_t *)adc_val, 0x1, SDIO_DATABLOCK_SIZE_512B, 1);
}
/******************************************************************************
* @brief  SD_SDIO_DMA_IRQHANDLER(void)
* @param  NONE
* @retval NONE
******************************************************************************/
void SD_SDIO_DMA_IRQHANDLER(void){
//	HAL_NVIC_ClearPendingIRQ(DMA2_Stream3_IRQn);
}
/******************************************************************************
* @brief  HAL_UART_RxCpltCallback(UART_HandleTypeDef * huart)
* @param  UART_HandleTypeDef * huart
* @retval NONE
******************************************************************************/
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart){ 	
	
	if(rxBuffer =='\n' || rxBuffer == '\r'){
		ADC1_SCHEDULE = atoi(rx_string);
		print(rx_string);
	}
	else{
		rx_string[rx_index] = rxBuffer;
		rx_index++;

		if(rx_index >= MAX_LEN){
			print(rx_string);
			rx_index=0;
			return;
		}	
	}
	HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_9);
	rx_index=0;
}
/******************************************************************************
* @brief  HAL_UART_TxCpltCallback(UART_HandleTypeDef * huart)
* @param  UART_HandleTypeDef * huart
* @retval NONE
******************************************************************************/
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart){

	HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_8);
}
/******************************************************************************
* @brief  HAL_UART_ErrorCallback(UART_HandleTypeDef * huart)
* @param  UART_HandleTypeDef * huart
* @retval NONE
******************************************************************************/
void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart){
	__HAL_UART_CLEAR_FLAG(huart, HAL_UART_STATE_ERROR);

}


void ENABLE_USART3(UART_HandleTypeDef* huart)
{
	/* Peripheral clock enable */
	//__USART3_CLK_ENABLE();
	//HAL_NVIC_EnableIRQ(USART3_IRQn);
	//while(HAL_UART_GetState(&huart3) == HAL_BUSY);
	print(USART_ENABLED);
	HAL_UART_Receive_IT(&huart3, (uint8_t*)&rxBuffer, sizeof(char));

}
void DISABLE_USART3(UART_HandleTypeDef * huart){
	print(USART_DISABLED);
	//while(HAL_UART_GetState(&huart3) == HAL_BUSY);

	//__USART3_CLK_DISABLE();
	//HAL_NVIC_DisableIRQ(USART3_IRQn);
	//HAL_UART_Transmit_IT(&huart3, (uint8_t*)USART_DISABLED, strlen(USART_DISABLED)+1);

}
/******************************************************************************
* @brief  HAL_I2C_MasterRxCpltCallback(I2C_HandleTypeDef * hi2c)
* @param  I2C_HandleTypeDef * hi2c
* @retval NONE
******************************************************************************/
void HAL_I2C_MemRxCpltCallback(I2C_HandleTypeDef *hi2c){
	char I2C_STRING[]="I2C MEMRX\r";
	HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_15);
	LIGHT_LEDS(data_to_read);
	print(I2C_STRING);
}
/******************************************************************************
* @brief  HAL_I2C_MasterRxCpltCallback(I2C_HandleTypeDef * hi2c)
* @param  I2C_HandleTypeDef * hi2c
* @retval NONE
******************************************************************************/
void HAL_I2C_MasterRxCpltCallback(I2C_HandleTypeDef * hi2c){
	#ifdef DEBUG
		char I2C_STRING[]="I2C MASTER RX\r";
		HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_15);
		LIGHT_LEDS(data_to_read);
		print(I2C_STRING);
	#endif
}

/*****************************************************************************
  * @brief  I2C error callbacks.
  * @param  hi2c : Pointer to a I2C_HandleTypeDef structure that contains
  *                the configuration information for the specified I2C.
  * @retval None
  */
void HAL_I2C_ErrorCallback(I2C_HandleTypeDef *hi2c)
{
	char I2C_ERROR[]="I2C_ERROR!\r";
	print(I2C_ERROR);
	if(__HAL_I2C_GET_FLAG(&hi2c1, I2C_FLAG_AF))
	__HAL_I2C_CLEAR_FLAG(&hi2c1, I2C_FLAG_AF);
}
/******************************************************************************
  * @brief  EXTI line detection callbacks.
  * @param  GPIO_Pin: Specifies the pins connected EXTI line
  * @retval None
  ****************************************************************************/
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	if(0==PROGRAM_STATE) PROGRAM_STATE=1;
	else PROGRAM_STATE=0;
	
	if(0==PROGRAM_STATE){
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_15, GPIO_PIN_SET);
		ENABLE_USART3(&huart3);
	}
	else{
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_15, GPIO_PIN_RESET);
		DISABLE_USART3(&huart3);
	}
}
/******************************************************************************
* @abstract LIGHT_LEDS function lights corresponding LEDS based on passed arg
* @ref LIGHT_LEDS(uint32_t value)
* @param uint32_t value - determines which LED(s) to light, ADC debugging!
******************************************************************************/
void LIGHT_LEDS(uint32_t value){
	if(value<1024){
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_15, GPIO_PIN_SET);
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_RESET);
	}
	else if(value>=1024&&value<2048){
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_15, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_SET);
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_RESET);
	}
	else if(value>=2048&&value<3072){
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_15, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_SET);
	}
	else if(value>=3072&& value<4096){
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_15, GPIO_PIN_RESET);		
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_RESET);
	}
	else{
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_15, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_RESET);
	}
}

/*
(#)Initialize the SDIO low level resources by implementing the HAL_SD_MspInit() API:
        (##) Enable the SDIO interface clock using __SDIO_CLK_ENABLE(); 
        (##) SDIO pins configuration for SD card
            (+++) Enable the clock for the SDIO GPIOs using the functions __GPIOx_CLK_ENABLE();   
            (+++) Configure these SDIO pins as alternate function pull-up using HAL_GPIO_Init()
                  and according to your pin assignment;
        (##) DMA Configuration if you need to use DMA process (HAL_SD_ReadBlocks_DMA()
             and HAL_SD_WriteBlocks_DMA() APIs).
            (+++) Enable the DMAx interface clock using __DMAx_CLK_ENABLE(); 
            (+++) Configure the DMA using the function HAL_DMA_Init() with predeclared and filled. 
        (##) NVIC configuration if you need to use interrupt process when using DMA transfer.
            (+++) Configure the SDIO and DMA interrupt priorities using functions
                  HAL_NVIC_SetPriority(); DMA priority is superior to SDIO's priority
            (+++) Enable the NVIC DMA and SDIO IRQs using function HAL_NVIC_EnableIRQ()
            (+++) SDIO interrupts are managed using the macros __HAL_SD_SDIO_ENABLE_IT() 
                  and __HAL_SD_SDIO_DISABLE_IT() inside the communication process.
            (+++) SDIO interrupts pending bits are managed using the macros __HAL_SD_SDIO_GET_IT()
                  and __HAL_SD_SDIO_CLEAR_IT()
    (#) At this stage, you can perform SD read/write/erase operations after SD card initialization  
*/
/******************************************************************************
* @abstract Initialize SD Card
* @ref SD_CARD_INIT(void)
* @param NONE
******************************************************************************/
void SD_CARD_INIT(void){
	__SDIO_CLK_ENABLE();
	__HAL_SD_SDIO_ENABLE();
	
	HAL_SD_CardInfoTypedef SD_info;
	
	SD_info.CardBlockSize = SDIO_DATABLOCK_SIZE_512B;

	HAL_SD_MspInit(&hsd);
	HAL_SD_Init(&hsd, &SD_info);
	
}
/******************************************************************************
* @abstract Trap the error condition and blink the RED LED on 
* @ref Error_Handler(void)
* @param uint32_t value - determines which LED(s) to light, ADC debugging!
******************************************************************************/
void Error_Handler(void){
	while(1){
		HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_15);
		HAL_Delay(100);
	}
}
/******************************************************************************
* @abstract Initialize the filesystem and do a test write to the card
* @ref SD_write_test(void)
* @param NONE
******************************************************************************/
void SD_write_test(void){
	
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_SET);
  /*##-1- Link the micro SD disk I/O driver ##################################*/
  if(FATFS_LinkDriver(&SD_Driver, SDPath) == 0)
  {
    /*##-2- Register the file system object to the FatFs module ##############*/
    if(f_mount(&SDFatFs, (TCHAR const*)SDPath, 0) != FR_OK)
    {
      /* FatFs Initialization Error */
      Error_Handler();
    }
    else
    {
      /*##-3- Create a FAT file system (format) on the logical drive #########*/
      /* WARNING: Formatting the uSD card will delete all content on the device */
      if(f_mkfs((TCHAR const*)SDPath, 0, 0) != FR_OK)
      {
        /* FatFs Format Error */
        Error_Handler();
      }
      else
      {       
        /*##-4- Create and Open a new text file object with write access #####*/
        if(f_open(&MyFile, "STM32.TXT", FA_CREATE_ALWAYS | FA_WRITE) != FR_OK)
        {
          /* 'STM32.TXT' file Open for write Error */
          Error_Handler();
        }
        else
        {
          /*##-5- Write data to the text file ################################*/
          res = f_write(&MyFile, wtext, sizeof(wtext), (void *)&byteswritten);
          
          if((byteswritten == 0) || (res != FR_OK))
          {
            /* 'STM32.TXT' file Write or EOF Error */
            Error_Handler();
          }
          else
          {
            /*##-6- Close the open text file #################################*/
            f_close(&MyFile);
            
            /*##-7- Open the text file object with read access ###############*/
            if(f_open(&MyFile, "STM32.TXT", FA_READ) != FR_OK)
            {
              /* 'STM32.TXT' file Open for read Error */
              Error_Handler();
            }
            else
            {
              /*##-8- Read data from the text file ###########################*/
              res = f_read(&MyFile, rtext, sizeof(rtext), (UINT*)&bytesread);
              
              if((bytesread == 0) || (res != FR_OK))
              {
                /* 'STM32.TXT' file Read or EOF Error */
                Error_Handler();
              }
              else
              {
                /*##-9- Close the open text file #############################*/
                f_close(&MyFile);
                
                /*##-10- Compare read data with the expected data ############*/
                if((bytesread != byteswritten))
                {                
                  /* Read data is different from the expected data */
                  Error_Handler();
                }
                else
                {
                  /* Success of the demo: no error occurrence */
                  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_SET);
  		  HAL_Delay(100);
                  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_RESET);

                }
              }
            }
          }
        }
      }
    }
  }
  
  /*##-11- Unlink the RAM disk I/O driver ####################################*/
  FATFS_UnLinkDriver(SDPath);
  
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_RESET);

}

/* USER CODE END 4 */

#ifdef USE_FULL_ASSERT

/**
   * @brief Reports the name of the source file and the source line number
   * where the assert_param error has occurred.
   * @param file: pointer to the source file name
   * @param line: assert_param error line source number
   * @retval None
   */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
    ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */

}

#endif

/**
  * @}
  */ 

/**
  * @}
*/ 

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
